# 监控系统导出包

## 导出信息
- 导出时间: 2026-03-08 13:38:07
- 数据目录: F:\workspace\yfjzworkspace\webspace\ai-template\uirecorder\filestorage\mydata
- 监控数据文件: 1 个
- 汇总数据文件: 1 个
- 截图文件: 4 个

## 文件结构
```
导出包/
├── data/                   # 监控数据文件
│   ├── monitoring_data_*.json
│   └── summary_*.json
├── screenshots/           # 截图文件
│   └── *.png
├── export_info.json       # 导出信息
└── README.md             # 说明文件
```

## 监控概览

### 操作统计
- 总操作次数: N/A
- 键盘操作: N/A
- 鼠标操作: N/A
- 录制时长: N/A

### 最新操作
暂无操作记录

## 使用说明
1. 监控数据文件包含详细的操作记录
2. 截图文件记录了关键操作的视觉证据
3. 可以使用任何JSON解析工具查看数据内容
4. 建议使用专业的数据分析工具进行进一步分析

---
导出工具: UIExporter ZIP Exporter v1.0
